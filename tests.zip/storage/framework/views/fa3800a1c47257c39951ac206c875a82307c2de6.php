

<?php $__env->startSection('head'); ?>
    <!-- Slick -->
    <link rel="stylesheet" href="<?php echo e(url('/vendors/slick/slick.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('/vendors/slick/slick-theme.css')); ?>" type="text/css">

    <!-- Daterangepicker -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/datepicker/daterangepicker.css')); ?>" type="text/css">

    <!-- DataTable -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/dataTable/datatables.min.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
                <div class="card-body">
                    <h6 class="card-title mb-0">Table Customers</h6>
                </div>
                <div class="table-responsive">
                    <table id="myTable" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                                    <th>Id Customer</th>
                                    <th>Nama</th>
                                    <th>Alamat</th>
                                    <th>Id Kelurahan</th>
                                    <th>Foto</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($cus -> ID_CUSTOMER); ?></td>
                                    <td><?php echo e($cus -> NAMA); ?></td>
                                    <td><?php echo e($cus -> ALAMAT); ?></td>
                                    <td><?php echo e($cus -> ID_KELURAHAN); ?></td>
                                    <td><?php echo e($cus -> FOTO); ?></td>
                                    </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- </tr> -->
                                    
                                    </tbody>
                                    <tfoot>
                        <tr>
                            <th>Id Barang</th>
                            <th>Nama Barang</th>
                            <th>Stock Barang</th>
                            <th>Deskripsi Barang</th>
                            <th>Cetak Barcode</th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
                    </table>
                </div>
                
        </div>
    </div>


          <?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function (){
    $('#myTable').DataTable();
});
</script>
    <!-- Sweet alert -->
    <script src="<?php echo e(url('assets/js/examples/sweet-alert.js')); ?>"></script>

    <!-- Prism -->
    <script src="<?php echo e(url('vendors/prism/prism.js')); ?>"></script>

     <!-- DataTable -->
    <script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/examples/datatable.js')); ?>"></script>

    <!-- Javascript -->
    <script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>

    <script>  
    toastr.options = {
        timeOut: 3000,
        progressBar: true,
        showMethod: "slideDown",
        hideMethod: "slideUp",
        showDuration: 200,
        hideDuration: 200
    };

toastr.success('Successfully completed');
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelimplementasi\resources\views/indexdropdown.blade.php ENDPATH**/ ?>