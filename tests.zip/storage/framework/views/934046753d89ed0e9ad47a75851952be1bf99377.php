<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Baston - Responsive Admin Dashboard Template</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(url('assets/media/image/favicon.png')); ?>"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/bundle.css')); ?>" type="text/css">

    <!-- App styles -->
    <link rel="stylesheet" href="<?php echo e(url('assets/css/app.min.css')); ?>" type="text/css">
</head>
<body class="form-membership" style="background: url(<?php echo e(url('assets/media/image/bgd.jpg')); ?>)">
<!-- Preloader -->
<div class="preloader">
    <img class="logo" src="<?php echo e(url('assets/media/image/logo/logo.png')); ?>" alt="logo">
    <img class="dark-logo" src="<?php echo e(url('assets/media/image/logo/dark-logo.png')); ?>" alt="logo dark">
    <div class="preloader-icon"></div>
</div>
<!-- ./ Preloader -->

<div class="form-wrapper">

    <!-- logo -->
    <div id="logo">
        <img class="logo" src="<?php echo e(url('assets/media/image/logo/logo.png')); ?>" alt="logo">
    </div>
    <!-- ./ logo -->

    <?php echo $__env->yieldContent('content'); ?>

</div>

<!-- Plugin scripts -->
<script src="<?php echo e(url('vendors/bundle.js')); ?>"></script>

<!-- App scripts -->
<script src="<?php echo e(url('assets/js/app.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravelimplementasi\resources\views/layouts/auth.blade.php ENDPATH**/ ?>